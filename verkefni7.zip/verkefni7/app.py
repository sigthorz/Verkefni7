from flask import Flask, render_template, redirect, request, session
import pyrebase


config = {
    "apiKey": "AIzaSyBtEKQhUbznkcBsBRrrSAI820PyvMSUrec",
    "authDomain": "mininews-3a335.firebaseapp.com",
    "databaseURL": "https://mininews-3a335-default-rtdb.europe-west1.firebasedatabase.app",
    "projectId": "mininews-3a335",
    "storageBucket": "mininews-3a335.appspot.com",
    "messagingSenderId": "2583870921",
    "appId": "1:2583870921:web:ee11760e12e00254f77c18",
    "measurementId": "G-ECRK06HNWT"
}

fb = pyrebase.initialize_app(config)
db = fb.database()

app = Flask(__name__)


@app.route('/')
def home():
    return render_template("frontpage.html")


@app.route('/article')
def article():
    return render_template("news_article.html")


@app.route('/admin')
def admin():
    return render_template("admin_page.html")


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
